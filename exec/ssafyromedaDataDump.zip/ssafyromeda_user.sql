-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i8d205.p.ssafy.io    Database: ssafyromeda
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_no` bigint NOT NULL AUTO_INCREMENT,
  `user_email` varchar(255) DEFAULT NULL,
  `user_nickname` varchar(255) DEFAULT NULL,
  `user_refresh_token` varchar(255) DEFAULT NULL,
  `user_role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_no`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (32,'pjh5699@nate.com','박재현','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2NzY4MTYwODl9.wds0rfQwrGV-ObLkmljvX5Yj1_HKKfE8laVvxbHuwpnwQdsiI6-A7J5dlT9A9mfdRzcASeiHhMy1Ttj7RlI8wg','USER'),(33,'magic9282m@gmail.com','떡튀순','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2NzY4MjQxNTV9.ZUpGcWMrys5vwujXZGfqDif8c4xFvOHczli2rebdeunPjYg2gEmhs3vRDMxeQciXa4voBzZiNqzjNEz6GFbNPA','USER'),(34,'shine7065@naver.com','whoami','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2NzY4NTczMjd9.NKg7bkFTOZrLjYDJnGSabi3vmv8MT7uKgHb7ggXQy2DbMNoCPqqlLW3-srNlS2U44tj5063t7KIbAjUE-WSo3g','USER'),(39,'spy03128@naver.com','지현','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2NzcwMzgwODd9.r2eGGYozh5MvIJ1uXRm4gRIIRAIZOnTjd1iMVtUNQkmr5bTmh9K6USEtj_JCHcLDx6OAka0K3refANpr3g-cmQ','USER'),(41,'tatybir@naver.com',NULL,NULL,'GUEST'),(42,'jh1997@kakao.com',NULL,NULL,'GUEST'),(43,'kys04171@naver.com',NULL,NULL,'GUEST'),(44,'wlsk227@daum.net',NULL,NULL,'GUEST'),(45,'ljc9393@nate.com',NULL,NULL,'GUEST'),(46,'xhxhwjrma@naver.com',NULL,NULL,'GUEST'),(47,'dpdms2148@naver.com','예은','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2Nzc2NTk4MTJ9.B55vPsxVDtDfxoLiCZ0vvcdbNQmXc9l5e03X3dP1AuzHwC623Lw56IIYEH-ECoOqParTSSf7eQNq_iUsJXYBfg','USER'),(48,'cmlee0913@naver.com','창민','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2Nzc2NTk4NjJ9.I8V6OD1zVi2k0mnP3-Zshv5d0pjJV-KzkA3GRo28-rTZkm18IgonGtu6Y2Sl7z-0cGFhcw6Qoia5cfXcdGnPVA','USER'),(49,'rkdahgus62@gmail.com','강모현','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2Nzc2NTk5NTV9.jB6ST_SpuS_1iw_oVOpQ1PNTR0pjo7TEKrKLLVHeoAnlMmRo8WXOTbW2dYXbGAX7DuOa6AMlahkaK7kONdDL-g','USER'),(50,'ngelinous@nate.com','해솜','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2Nzc2NTk3NTd9.HY1gLjcE8oRW2IE5iVztDfZ8GPxSyNnzpASnaOZmeRkYs9a4ccHxLTyygaWSYnmqT7v6vPlpOzDFZouTo-nRCw','USER'),(51,'kimtjddnr254@naver.com','성욱','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2Nzc2NzM1NTh9.DcSaGJ4N2xJZcbrATqWpGqOEBHJ2AkXABvab0mva2x9FiGTJ95x54dtHFH2PpMISaFQt00c18PBdGqX48sZtCg','USER'),(52,'pyooooong@gmail.com','정은','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2Nzc2NTg0MTR9.XDcGluU0DlSndLORnWvV8IHSE1njPa7YOnwDXwi-9hTSstPVnBCZ3bobKgxrz_HttLMdf2uhC1-cj7tyUZdWgA','USER'),(53,'ch03124@nate.com',NULL,NULL,'GUEST'),(54,'huuuuuhui@kakao.com','박정은','eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJSZWZyZXNoVG9rZW4iLCJleHAiOjE2Nzc2NTYyOTR9.YfVCGvBp57sO7ny2O-5mvdhjJb5m2rEd2mICmMYdoh_ZAcAOBoRhab3bee8qcQEmG1feSYFnXDDgFcnTBauSBw','USER'),(55,'tmfdhddl2006@naver.com',NULL,NULL,'GUEST');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-15 22:17:23
